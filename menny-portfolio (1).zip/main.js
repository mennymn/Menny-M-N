(function () {
  "use strict";

  /* ---------- Theme (persisted, falls back to system preference) ---------- */
  var root = document.documentElement;
  var themeBtn = document.getElementById("themeToggle");
  var saved = null;
  try { saved = localStorage.getItem("theme"); } catch (e) {}
  var prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  root.setAttribute("data-theme", saved || (prefersDark ? "dark" : "light"));

  themeBtn.addEventListener("click", function () {
    var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  /* ---------- Mobile nav ---------- */
  var navToggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("nav");
  navToggle.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(open));
  });
  nav.addEventListener("click", function (e) {
    if (e.target.tagName === "A") {
      nav.classList.remove("open");
      navToggle.setAttribute("aria-expanded", "false");
    }
  });

  /* ---------- Typing effect ---------- */
  var roles = ["Mathematics Educator", "Assistant Professor", "Guest Lecturer", "Lifelong Learner"];
  var typedEl = document.getElementById("typed");
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var r = 0, c = 0, deleting = false;

  function type() {
    var word = roles[r];
    typedEl.textContent = word.substring(0, c);
    if (!deleting && c < word.length) { c++; return setTimeout(type, 90); }
    if (!deleting) { deleting = true; return setTimeout(type, 1400); }
    if (c > 0) { c--; return setTimeout(type, 45); }
    deleting = false;
    r = (r + 1) % roles.length;
    setTimeout(type, 300);
  }
  if (reduceMotion) { typedEl.textContent = roles[0]; } else { type(); }

  /* ---------- Scroll reveal, counters and progress bars ---------- */
  function animateCount(el) {
    var target = parseFloat(el.dataset.target);
    var decimals = parseInt(el.dataset.decimals || "0", 10);
    var suffix = el.dataset.suffix || "";
    var start = null, duration = 1400;
    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = (target * eased).toFixed(decimals) + suffix;
      if (p < 1) requestAnimationFrame(step);
    }
    if (reduceMotion) { el.textContent = target.toFixed(decimals) + suffix; }
    else { requestAnimationFrame(step); }
  }

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      var el = entry.target;
      el.classList.add("visible");
      var bar = el.querySelector(".bar");
      if (bar) bar.firstElementChild.style.width = bar.dataset.value + "%";
      io.unobserve(el);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });

  var counterIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) { animateCount(entry.target); counterIO.unobserve(entry.target); }
    });
  }, { threshold: 0.6 });
  document.querySelectorAll(".num").forEach(function (el) { counterIO.observe(el); });

  /* ---------- Active nav link on scroll ---------- */
  var links = Array.prototype.slice.call(document.querySelectorAll(".nav a"));
  var sections = links.map(function (a) { return document.querySelector(a.getAttribute("href")); });
  var spy = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      links.forEach(function (a) {
        a.classList.toggle("active", a.getAttribute("href") === "#" + entry.target.id);
      });
    });
  }, { rootMargin: "-40% 0px -55% 0px" });
  sections.forEach(function (s) { if (s) spy.observe(s); });

  /* ---------- Contact form (opens the visitor's mail app) ---------- */
  var form = document.getElementById("contactForm");
  var status = document.getElementById("formStatus");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var ok = true;
    Array.prototype.forEach.call(form.elements, function (f) {
      if (!f.name) return;
      var valid = f.value.trim() !== "" && (f.type !== "email" || /^\S+@\S+\.\S+$/.test(f.value));
      f.classList.toggle("invalid", !valid);
      if (!valid) ok = false;
    });
    if (!ok) { status.textContent = "Please fill in all fields with a valid email."; return; }
    var subject = encodeURIComponent("Portfolio enquiry from " + form.name.value.trim());
    var body = encodeURIComponent(form.message.value.trim() + "\n\n" + form.name.value.trim() + " (" + form.email.value.trim() + ")");
    window.location.href = "mailto:menn912@gmail.com?subject=" + subject + "&body=" + body;
    status.textContent = "Opening your email app...";
  });

  /* ---------- Footer year ---------- */
  document.getElementById("year").textContent = new Date().getFullYear();
})();
