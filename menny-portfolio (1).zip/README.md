# Menny M N | Personal Portfolio

A responsive, dependency-free portfolio website for Menny M N, Mathematics educator (M.Sc. Mathematics), built with plain HTML, CSS and JavaScript from her resume.

## Features

- Hero section with typing animation and profile photo
- Animated stats, education score bars and scroll-reveal timeline
- Sections: About, Experience, Education, Strengths, Achievements, Contact
- Light / dark theme toggle (remembers the choice)
- Mobile navigation, active-section highlighting, print-friendly styles
- Contact form that opens the visitor's email app (no backend needed)
- Respects `prefers-reduced-motion`

## Files

All files sit together in one folder, with no subfolders.

- `index.html` – page content
- `style.css` – styling
- `main.js` – interactivity
- `profile.jpg` – profile photo
- `README.md` – this file

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# visit http://localhost:8000
```

## Deploy on GitHub Pages

1. Upload these five files to the root of a GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. The site will be live at `https://<your-username>.github.io/<repo-name>/`.

## Customising

- Text and details: edit `index.html`
- Colours and fonts: edit the CSS variables at the top of `style.css`
- Typing roles: edit the `roles` array in `main.js`
- Photo: replace `profile.jpg`
